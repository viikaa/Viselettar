const Schema = require('mongoose').Schema;
const db = require('../config/db');

const Viselet = db.model('Viselet', {
  name: String,
  region: String,
  color: String,
  _ownedBy: {
    type: Schema.Types.ObjectId,
    ref: 'Tancos'
  }
});

module.exports = Viselet;