const Schema = require('mongoose').Schema;
const db = require('../config/db');

const Tancos = db.model('Tancos', {
  name: String,
  sex: String,
  year: Number,
  month: Number,
  day: Number
});

module.exports = Tancos;