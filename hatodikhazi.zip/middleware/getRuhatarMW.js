const requireOption = require('./requireOption');

module.exports = function (objectrepository) {
    let tancosModel = requireOption(objectrepository, 'tancosModel');
    
    return function (req, res, next) {
        tancosModel.findOne({
            name: 'Ruhatár'
        }, (err, result) => {
            if(!result){
                 result = new tancosModel();
                 result.name = 'Ruhatár';
                 result.save();
            }
            res.locals.ruhatar = result;
            return next();
        });   
    };
};