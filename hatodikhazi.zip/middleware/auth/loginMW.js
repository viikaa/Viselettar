const mongoose = require('mongoose');
const requireOption = require('../requireOption');

module.exports = function (objectrepository) {
    const userModel = requireOption(objectrepository, 'userModel');
    return function (req, res, next) {
        if ((typeof req.body === 'undefined') || (typeof req.body.password === 'undefined')) {
            return next();
        }

        userModel.findOne({
            email: req.body.email
        }, (err, result)=> {
            if(err || (!result)){
                return next();
            }
            res.locals.user = result;
            if(req.body.password !== res.locals.user.password){
                return next();
            }
            req.session.sessionID = mongoose.Types.ObjectId();
            res.redirect('/');
        });
    };
};