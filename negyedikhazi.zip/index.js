
const express = require('express');
const app = express();
const session = require('express-session');
app.set('view engine', 'ejs');

app.use(express.static('static'));

app.use(session({
    secret: 'keyboard cat',
    cookie: {
      maxAge: 60000
    },
    resave: true,
    saveUninitialized: false
}));

require('./route/index')(app);

let server = app.listen(3000, function () {
});