const authMW = require('../middleware/auth/authMW');
const checkPassMW = require('../middleware/auth/checkPassMW');
const renderMW = require('../middleware/renderMW');
const redirectMW = require('../middleware/redirectMW')
const delTancosMW = require('../middleware/tancos/delTancosMW');
const getTancosokMW = require('../middleware/tancos/getTancosokMW');
const getTancosMW = require('../middleware/tancos/getTancosMW');
const saveTancosMW = require('../middleware/tancos/saveTancosMW');
const delViseletMW = require('../middleware/viselet/delViseletMW');
const getViseletekMW = require('../middleware/viselet/getViseletekMW');
const getViseletMW = require('../middleware/viselet/getViseletMW');
const saveViseletMW = require('../middleware/viselet/saveViseletMW');

module.exports = function (app) {
    const objRepo = {};

    app.get('/tancos',
        authMW(objRepo),
        getTancosokMW(objRepo),
        renderMW(objRepo, 'tancosok'));
    app.use('/tancos/new',
        authMW(objRepo),
        saveTancosMW(objRepo),
        renderMW(objRepo, 'tancosadatlap'));
    app.use('/tancos/:tancosid',
        authMW(objRepo),
        getTancosMW(objRepo),
        saveTancosMW(objRepo),
        renderMW(objRepo, 'tancosadatlap'));
    app.get('/tancos/:tancosid/del',
        authMW(objRepo),
        getTancosMW(objRepo),
        delTancosMW(objRepo));

    app.get('/viselet',
        authMW(objRepo),
        getViseletekMW(objRepo),
        renderMW(objRepo, 'viseletek'));
    app.use('/viselet/new',
        authMW(objRepo),
        saveViseletMW(objRepo),
        renderMW(objRepo, 'viseletadatlap'));
    app.use('/viselet/:viseletid',
        authMW(objRepo),
        getViseletMW(objRepo),
        saveViseletMW(objRepo),
        renderMW(objRepo, 'viseletadatlap'));
    app.get('/viselet/:viseletid/atadas',
        authMW(objRepo),
        getViseletMW(objRepo),
        saveViseletMW(objRepo));
    app.get('/viselet/:viseletid/del',
        authMW(objRepo),
        getViseletMW(objRepo),
        delViseletMW(objRepo),);

    app.use('/',
        checkPassMW(objRepo),
        authMW(objRepo),
        renderMW(objRepo, 'index'));
};