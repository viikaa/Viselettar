var Schema = require('mongoose').Schema;
var db = require('../config/db');

var Tancos = db.model('Tancos', {
  name: String,
  sex: String,
  year: Number,
  month: Number,
  day: Number
});

module.exports = Tancos;