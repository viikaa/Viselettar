/**
 * If the user is authenticated, call next, otherwise redirect to /
 */
const requireOption = require('../requireOption');

module.exports = function (objectrepository) {

    let tancosModel = requireOption(objectrepository, 'tancosModel')

    return function (req, res, next) {
        tancosModel.findOne({
            id: req.param('name')
        }, (err, result) => {
            if((err) || (!result)){
                return res.redirect('/tancos');
            }
            res.locals.tancos = result;
            return next();
        });

        
    };
};